# Hints

We recommend you try solving the challenge with only the stripped binary first as this is common for reversing.
[Ghidra](https://ghidra-sre.org/) is a very useful tool for that (it's free and open-source).
For dealing with input/output of the server, [pwntools](https://github.com/Gallopsled/pwntools) might be helpful.
If you get stuck, see [the help below](#help).

Have fun hacking!

## Tool introduction

### Ghidra

We can recommend [this quickstart guide](https://www.youtube.com/watch?v=fTGTnrgjuGA) by @stacksmashing.
There's a [cheat sheet](https://ghidra-sre.org/CheatSheet.html) too but you will probably use `L` for renaming and `CTRL+L` for retyping variables.

### pwntools

You can use `pwn.remote` for easy interaction with the server (and `pwn.process` for local setups, should you need them in other challenges).
See the [tube docs](https://docs.pwntools.com/en/stable/tubes/sockets.html#pwnlib.tubes.remote.remote) for an overview of the interface.
The `recv` and `send` variants provide utility for almost every use case and `interactive` let's you communicate with a remote or process directly.
Additionally, you can start your pwntools script with an extra `DEBUG` argument to see all bytes sent and received.

## Help

For starting out, you will find the main method as the first argument passed to `libc_start_main` in the entry point.

If you are struggling to understand the client without any symbols, feel free to use the unstripped version.
You could also open both and compare the places that confuse you.

Additionally, we included the source file in case you need additional help.
You can also use those to find out what you understood correctly or what you missed after solving the challenge.
