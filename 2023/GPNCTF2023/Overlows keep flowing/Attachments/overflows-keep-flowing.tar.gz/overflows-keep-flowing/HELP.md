Some keywords that might help:
- Buffer overflow
- ROP chain
- Cyclics are helpful in pwntools
