Wait, should this file be that large?
